#version 150

#moj_import <interfaces.glsl>
in vec3 Position;
in vec2 UV0;

uniform sampler2D Sampler0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform float GameTime;


out vec2 texCoord0;

void main() {

    Data data = position_tex(ProjMat, GameTime, Sampler0, Position, UV0);
    texCoord0 = data.uv0;    
    gl_Position = ProjMat * ModelViewMat * vec4(data.position, 1.0);
}